import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { apiClient, setAuthFailureHandler, setAuthToken } from "../api/client";

const AuthContext = createContext(null);

const STORAGE_KEY = "aiwse:auth";

function persist(next) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  return next;
}

export function AuthProvider({ children }) {
  const [auth, setAuth] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      const stored = raw ? JSON.parse(raw) : null;
      if (!stored?.token || !stored?.studentId) {
        localStorage.removeItem(STORAGE_KEY);
        setAuthToken(null);
        return null;
      }
      // Restore the interceptor token before child effects issue authenticated requests.
      setAuthToken(stored.token);
      return stored;
    } catch {
      localStorage.removeItem(STORAGE_KEY);
      setAuthToken(null);
      return null;
    }
  });

  useEffect(() => {
    setAuthToken(auth?.token || null);
  }, [auth]);

  useEffect(() => {
    setAuthFailureHandler((error) => {
      if (error?.response?.status !== 401) {
        return;
      }

      // Preserve internship progress across sessions: only the auth token is
      // cleared here. The cached simulation ("aiwse:simulation") is kept so a
      // re-login can resume it, and the backend remains the source of truth.
      localStorage.removeItem(STORAGE_KEY);
      setAuthToken(null);
      setAuth(null);
    });

    return () => {
      setAuthFailureHandler(null);
    };
  }, []);

  const applySession = useCallback((data) => {
    setAuthToken(data.access_token);
    const next = persist({
      token: data.access_token,
      studentId: data.student_id,
      role: data.role,
      email: data.email || null,
      fullName: data.full_name || null,
    });
    setAuth(next);
    return next;
  }, []);

  const login = useCallback(async (email, password) => {
    const res = await apiClient.post("/api/auth/login", { email, password });
    return applySession(res.data);
  }, [applySession]);

  const register = useCallback(async ({ email, password, fullName }) => {
    const res = await apiClient.post("/api/auth/register", {
      email,
      password,
      full_name: fullName,
    });
    return applySession(res.data);
  }, [applySession]);

  const loginDev = useCallback(async (studentId, role = "student") => {
    const res = await apiClient.post("/api/dev/token", { student_id: studentId, role });
    return applySession(res.data);
  }, [applySession]);

  const logout = useCallback(() => {
    // Keep "aiwse:simulation" so internship progress is preserved across
    // logout and login. The simulation cache is namespaced per student on
    // restore (see Onboarding/RequireSimulation), and the backend remains
    // the source of truth.
    localStorage.removeItem(STORAGE_KEY);
    setAuthToken(null);
    setAuth(null);
  }, []);

  return (
    <AuthContext.Provider value={{ auth, login, register, loginDev, logout, isAuthenticated: Boolean(auth?.token) }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
