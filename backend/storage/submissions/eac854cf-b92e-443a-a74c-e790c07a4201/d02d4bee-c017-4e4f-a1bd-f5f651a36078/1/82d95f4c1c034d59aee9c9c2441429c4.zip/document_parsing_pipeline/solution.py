import os
import uuid
import zipfile
import logging
from pathlib import Path

from celery import Celery
from celery.result import AsyncResult
from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, Header
from pydantic import BaseModel
from pypdf import PdfReader
from docx import Document

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BASE_DIR = Path(os.getenv("UPLOAD_DIR", "./uploads")).resolve()
BASE_DIR.mkdir(parents=True, exist_ok=True)
MAX_FILE_SIZE = 10 * 1024 * 1024
CHUNK_SIZE = 64 * 1024

celery_app = Celery(
    "document_parser",
    broker=os.getenv("CELERY_BROKER_URL", "amqp://guest:guest@localhost:5672//"),
    backend=os.getenv("CELERY_RESULT_BACKEND", "redis://localhost:6379/0"),
)
celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_reject_on_worker_lost=True,
    result_expires=3600,
)

app = FastAPI(title="Asynchronous Document Parsing API", version="1.0.0")
API_KEY = os.getenv("PARSE_API_KEY")


async def authenticate(x_api_key: str | None = Header(default=None)):
    if not API_KEY:
        if os.getenv("APP_ENV", "development") != "development":
            raise HTTPException(status_code=503, detail="Authentication is not configured")
        return
    if not x_api_key or x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")


class UploadResponse(BaseModel):
    task_id: str
    status: str


class TaskResponse(BaseModel):
    task_id: str
    status: str
    result: dict | None = None
    error: str | None = None


def validate_file_signature(path: Path, extension: str) -> None:
    try:
        with path.open("rb") as file:
            header = file.read(8)
        if extension == ".pdf":
            if not header.startswith(b"%PDF-"):
                raise ValueError("Invalid PDF signature")
        elif extension == ".docx":
            if not header.startswith(b"PK"):
                raise ValueError("Invalid DOCX signature")
            with zipfile.ZipFile(path) as archive:
                names = set(archive.namelist())
                if "[Content_Types].xml" not in names or "word/document.xml" not in names:
                    raise ValueError("Invalid DOCX structure")
                if archive.testzip() is not None:
                    raise ValueError("Corrupted DOCX archive")
        else:
            raise ValueError("Unsupported document format")
    except (zipfile.BadZipFile, OSError) as exc:
        raise ValueError("Corrupted or unreadable document") from exc


def extract_text(path: Path, extension: str) -> str:
    try:
        if extension == ".pdf":
            reader = PdfReader(str(path), strict=True)
            if reader.is_encrypted:
                raise ValueError("Encrypted PDFs are not supported")
            text = "\n".join(page.extract_text() or "" for page in reader.pages)
        elif extension == ".docx":
            document = Document(str(path))
            parts = [p.text for p in document.paragraphs if p.text.strip()]
            for table in document.tables:
                for row in table.rows:
                    parts.append(" | ".join(cell.text for cell in row.cells))
            text = "\n".join(parts)
        else:
            raise ValueError("Unsupported document format")
        if not text.strip():
            raise ValueError("No extractable text found; scanned PDFs may require OCR")
        return text.strip()
    except ValueError:
        raise
    except Exception as exc:
        logger.warning("Document extraction failed: %s", type(exc).__name__)
        raise ValueError("Document is corrupted or cannot be parsed") from exc


@celery_app.task(bind=True, name="parse_document", max_retries=2, default_retry_delay=3)
def parse_document(self, file_path: str, extension: str):
    path = Path(file_path).resolve()
    if not path.is_relative_to(BASE_DIR):
        raise ValueError("Invalid document path")
    try:
        validate_file_signature(path, extension)
        text = extract_text(path, extension)
        return {
            "status": "completed",
            "filename": path.name,
            "character_count": len(text),
            "text": text,
        }
    except ValueError:
        raise
    except OSError as exc:
        raise self.retry(exc=exc) from exc


@celery_app.task(name="cleanup_document")
def cleanup_document(file_path: str):
    path = Path(file_path).resolve()
    if path.is_relative_to(BASE_DIR):
        path.unlink(missing_ok=True)


@app.post("/documents", response_model=UploadResponse, status_code=202,
          dependencies=[Depends(authenticate)])
async def upload_document(file: UploadFile = File(...)):
    filename = (file.filename or "").strip()
    extension = Path(filename).suffix.lower()
    if extension not in {".pdf", ".docx"}:
        raise HTTPException(status_code=415, detail="Only PDF and DOCX files are supported")

    task_id = str(uuid.uuid4())
    destination = (BASE_DIR / f"{task_id}{extension}").resolve()
    if not destination.is_relative_to(BASE_DIR):
        raise HTTPException(status_code=400, detail="Invalid filename")

    size = 0
    try:
        with destination.open("xb") as output:
            while True:
                chunk = await file.read(CHUNK_SIZE)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_FILE_SIZE:
                    raise HTTPException(status_code=413, detail="File exceeds the 10 MB limit")
                output.write(chunk)
        if size == 0:
            raise HTTPException(status_code=400, detail="Empty file")
        validate_file_signature(destination, extension)
        parse_document.apply_async(args=[str(destination), extension], task_id=task_id)
        return UploadResponse(task_id=task_id, status="queued")
    except HTTPException:
        destination.unlink(missing_ok=True)
        raise
    except ValueError as exc:
        destination.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        destination.unlink(missing_ok=True)
        logger.exception("Could not enqueue document task")
        raise HTTPException(status_code=503, detail="Unable to queue document for processing") from exc
    finally:
        await file.close()


@app.get("/documents/{task_id}", response_model=TaskResponse,
         dependencies=[Depends(authenticate)])
def get_document_status(task_id: str):
    try:
        uuid.UUID(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid task ID") from exc

    task = AsyncResult(task_id, app=celery_app)
    state = task.state
    if state == "PENDING":
        return TaskResponse(task_id=task_id, status="pending")
    if state == "STARTED":
        return TaskResponse(task_id=task_id, status="processing")
    if state == "SUCCESS":
        result = task.result
        return TaskResponse(task_id=task_id, status="completed",
                            result=result if isinstance(result, dict) else None)
    if state == "FAILURE":
        return TaskResponse(task_id=task_id, status="failed",
                            error="Document parsing failed")
    return TaskResponse(task_id=task_id, status=state.lower())
