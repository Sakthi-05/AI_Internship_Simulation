import io
from docx import Document
from fastapi import HTTPException
from unittest.mock import Mock
import solution


def make_docx_bytes():
    stream = io.BytesIO()
    doc = Document()
    doc.add_paragraph("Resume text")
    doc.save(stream)
    return stream.getvalue()


def test_upload_unsupported_type(client, auth_headers):
    response = client.post("/documents", headers=auth_headers,
                           files={"file": ("resume.txt", b"text", "text/plain")})
    assert response.status_code == 415


def test_upload_empty_file(client, auth_headers):
    response = client.post("/documents", headers=auth_headers,
                           files={"file": ("resume.pdf", b"", "application/pdf")})
    assert response.status_code == 400


def test_upload_corrupt_pdf(client, auth_headers):
    response = client.post("/documents", headers=auth_headers,
                           files={"file": ("resume.pdf", b"not a pdf", "application/pdf")})
    assert response.status_code == 400


def test_upload_docx_queues_task(client, auth_headers, monkeypatch):
    mocked = Mock()
    monkeypatch.setattr(solution.parse_document, "apply_async", mocked)
    response = client.post("/documents", headers=auth_headers,
                           files={"file": ("resume.docx", make_docx_bytes(),
                                           "application/vnd.openxmlformats-officedocument.wordprocessingml.document")})
    assert response.status_code == 202
    body = response.json()
    assert body["status"] == "queued"
    assert body["task_id"]
    mocked.assert_called_once()


def test_missing_api_key_rejected(client):
    response = client.post("/documents",
                           files={"file": ("resume.txt", b"x", "text/plain")})
    assert response.status_code == 401


def test_invalid_task_id(client, auth_headers):
    response = client.get("/documents/not-a-uuid", headers=auth_headers)
    assert response.status_code == 400
