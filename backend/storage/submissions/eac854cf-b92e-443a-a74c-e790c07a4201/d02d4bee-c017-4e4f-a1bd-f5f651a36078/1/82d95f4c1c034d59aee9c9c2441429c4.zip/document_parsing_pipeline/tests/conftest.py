import pytest
from fastapi.testclient import TestClient
import solution


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(solution, "BASE_DIR", tmp_path.resolve())
    monkeypatch.setattr(solution, "API_KEY", "test-key")
    return TestClient(solution.app)


@pytest.fixture()
def auth_headers():
    return {"X-API-Key": "test-key"}
