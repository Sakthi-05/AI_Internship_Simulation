from pathlib import Path
import pytest
import solution


def test_parse_task_rejects_path_outside_upload_dir(tmp_path, monkeypatch):
    base = tmp_path / "uploads"
    base.mkdir()
    outside = tmp_path / "outside.pdf"
    outside.write_bytes(b"%PDF-1.4")
    monkeypatch.setattr(solution, "BASE_DIR", base.resolve())
    with pytest.raises(ValueError, match="Invalid document path"):
        solution.parse_document.run(str(outside), ".pdf")


def test_parse_task_rejects_corrupt_document(tmp_path, monkeypatch):
    monkeypatch.setattr(solution, "BASE_DIR", tmp_path.resolve())
    path = tmp_path / "corrupt.pdf"
    path.write_bytes(b"%PDF-invalid")
    with pytest.raises(ValueError):
        solution.parse_document.run(str(path), ".pdf")


def test_parse_task_docx(tmp_path, monkeypatch):
    from docx import Document
    monkeypatch.setattr(solution, "BASE_DIR", tmp_path.resolve())
    path = tmp_path / "resume.docx"
    doc = Document()
    doc.add_paragraph("Backend Engineer")
    doc.save(path)
    result = solution.parse_document.run(str(path), ".docx")
    assert result["status"] == "completed"
    assert "Backend Engineer" in result["text"]
