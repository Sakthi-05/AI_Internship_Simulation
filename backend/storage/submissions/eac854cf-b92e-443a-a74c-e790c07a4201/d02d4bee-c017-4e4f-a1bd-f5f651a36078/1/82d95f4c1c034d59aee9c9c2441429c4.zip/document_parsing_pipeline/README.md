# Asynchronous Resume Document Parsing Pipeline

A foundational FastAPI + Celery pipeline for asynchronous PDF and DOCX text extraction, using RabbitMQ as the message broker and Redis as the Celery result backend.

## Features

- `POST /documents`: validates and uploads PDF/DOCX; returns HTTP 202 and a task ID.
- `GET /documents/{task_id}`: retrieves asynchronous task state/result.
- PDF text extraction using `pypdf`.
- DOCX paragraphs and tables extracted using `python-docx`.
- File-size limit (10 MB), extension and signature checks, corrupt-file handling.
- Celery worker configuration for late acknowledgements and low prefetch.
- API-key authentication when `PARSE_API_KEY` is configured.
- Unit and API tests with coverage reporting.

## Requirements

- Python 3.10+
- Docker Desktop
- Dependencies in `requirements.txt`

## Setup

### 1. Start RabbitMQ and Redis

```bash
docker compose up -d
```

RabbitMQ management UI: http://localhost:15672 (local default credentials: guest / guest).

### 2. Install dependencies

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
$env:APP_ENV="development"
$env:PARSE_API_KEY="your-local-test-key"
$env:CELERY_BROKER_URL="amqp://guest:guest@localhost:5672//"
$env:CELERY_RESULT_BACKEND="redis://localhost:6379/0"
```

Linux/macOS:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export APP_ENV=development
export PARSE_API_KEY='your-local-test-key'
export CELERY_BROKER_URL='amqp://guest:guest@localhost:5672//'
export CELERY_RESULT_BACKEND='redis://localhost:6379/0'
```

For local development, environment variables are read from the shell. The `.env.example` file is a template; this app does not automatically load `.env`.

### 3. Start API

```bash
uvicorn solution:app --reload
```

### 4. Start Celery worker in a second terminal

Activate the same virtual environment and set the same environment variables, then run:

```bash
celery -A solution.celery_app worker --loglevel=info
```

On Windows, Celery's prefork pool may not be supported in all configurations. For local development use:

```bash
celery -A solution.celery_app worker --pool=solo --loglevel=info
```

### 5. Try the API

Open http://127.0.0.1:8000/docs. Include `X-API-Key: your-local-test-key` for both endpoints.

Upload a resume to `POST /documents`. Save the returned `task_id`, then poll `GET /documents/{task_id}` until status is `completed` or `failed`.

Example cURL:

```bash
curl -X POST "http://127.0.0.1:8000/documents" \
  -H "X-API-Key: your-local-test-key" \
  -F "file=@resume.pdf"
```

## Tests and coverage

```bash
pytest --cov=solution --cov-report=term-missing --cov-fail-under=85
```

The test suite mocks queue submission for API tests, so RabbitMQ/Redis are not needed to run the unit tests. Run live integration tests against actual broker services before deploying.

## Design notes and production hardening

- Local disk is suitable only when API and workers share a filesystem. For multi-host production deployments, use private object storage and pass an object key to Celery.
- Store task ownership, state, retention metadata, and parsed text in a database/object store. Celery result-backend data alone is not a durable application data model.
- The status endpoint should enforce user/tenant ownership in production; a task UUID is not an authorization mechanism.
- Add rate limiting, malware scanning, quotas, encrypted storage, and secure retention/deletion policies for resumes.
- Image-only/scanned PDFs need an OCR stage; this implementation reports that no extractable text was found.
- Add broker-backed integration tests, load tests, metrics, and a dead-letter/retry policy before calling the service production-ready.
- The 85% coverage target must be verified by running the command above in the target environment; do not claim coverage without the report.
