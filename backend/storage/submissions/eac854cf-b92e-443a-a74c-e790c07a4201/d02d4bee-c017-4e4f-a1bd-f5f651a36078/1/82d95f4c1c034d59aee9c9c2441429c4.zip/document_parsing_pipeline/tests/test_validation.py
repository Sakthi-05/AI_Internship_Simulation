import zipfile
import pytest
from pathlib import Path
from docx import Document
import solution


def test_rejects_unsupported_extension(tmp_path):
    with pytest.raises(ValueError, match="Unsupported"):
        solution.validate_file_signature(tmp_path / "x.txt", ".txt")


def test_rejects_bad_pdf_signature(tmp_path):
    path = tmp_path / "bad.pdf"
    path.write_bytes(b"not a pdf")
    with pytest.raises(ValueError, match="signature"):
        solution.validate_file_signature(path, ".pdf")


def test_rejects_bad_docx_zip(tmp_path):
    path = tmp_path / "bad.docx"
    path.write_bytes(b"PK but not a zip")
    with pytest.raises(ValueError):
        solution.validate_file_signature(path, ".docx")


def test_valid_docx_extracts_paragraph_and_table(tmp_path):
    path = tmp_path / "resume.docx"
    doc = Document()
    doc.add_paragraph("Sakthi - Software Engineer")
    table = doc.add_table(rows=1, cols=1)
    table.cell(0, 0).text = "Python"
    doc.save(path)
    solution.validate_file_signature(path, ".docx")
    text = solution.extract_text(path, ".docx")
    assert "Software Engineer" in text
    assert "Python" in text


def test_empty_docx_text_raises(tmp_path):
    path = tmp_path / "empty.docx"
    Document().save(path)
    with pytest.raises(ValueError, match="No extractable text"):
        solution.extract_text(path, ".docx")


def test_cleanup_only_inside_base_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(solution, "BASE_DIR", tmp_path.resolve())
    target = tmp_path / "delete.txt"
    target.write_text("temporary")
    solution.cleanup_document.run(str(target))
    assert not target.exists()


def test_cleanup_does_not_delete_outside_base_dir(tmp_path, monkeypatch):
    base = tmp_path / "uploads"
    base.mkdir()
    outside = tmp_path / "outside.txt"
    outside.write_text("keep")
    monkeypatch.setattr(solution, "BASE_DIR", base.resolve())
    solution.cleanup_document.run(str(outside))
    assert outside.exists()
