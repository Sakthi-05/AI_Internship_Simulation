import io, zipfile
from unittest.mock import patch
from fastapi import HTTPException
from app.security import safe_extension, detect_type
def docx_bytes():
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w") as z:
        z.writestr("[Content_Types].xml", "<Types/>"); z.writestr("word/document.xml", "<document/>")
    return out.getvalue()
def test_requires_auth(client):
    assert client.post("/api/v1/resumes", files={"file": ("x.pdf", b"%PDF-1.4", "application/pdf")}).status_code == 401
def test_rejects_extension():
    try: safe_extension("bad.exe"); assert False
    except HTTPException as e: assert e.status_code == 415
def test_rejects_pdf_signature():
    try: detect_type(b"not pdf", ".pdf"); assert False
    except HTTPException as e: assert e.status_code == 415
def test_rejects_invalid_docx():
    try: detect_type(b"PK\\x03\\x04notzip", ".docx"); assert False
    except HTTPException as e: assert e.status_code in (400, 415)
def test_empty_upload(client):
    assert client.post("/api/v1/resumes", headers={"X-User-ID":"u1"}, files={"file": ("x.pdf", b"", "application/pdf")}).status_code == 400
def test_wrong_mime(client):
    assert client.post("/api/v1/resumes", headers={"X-User-ID":"u1"}, files={"file": ("x.pdf", b"%PDF-1.4 fake", "text/plain")}).status_code == 415
def test_unknown_job(client):
    assert client.get("/api/v1/resumes/nope", headers={"X-User-ID":"u1"}).status_code == 404
def test_other_user_cannot_read_job(client):
    with patch("app.main.scan_with_clamav"), patch("app.main.parse_resume.delay"):
        r = client.post("/api/v1/resumes", headers={"X-User-ID":"owner"}, files={"file": ("x.docx", docx_bytes(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document")})
    assert r.status_code == 202
    assert client.get(f"/api/v1/resumes/{r.json()['job_id']}", headers={"X-User-ID":"intruder"}).status_code == 404
def test_valid_docx_queued(client):
    with patch("app.main.scan_with_clamav"), patch("app.main.parse_resume.delay") as enqueue:
        r = client.post("/api/v1/resumes", headers={"X-User-ID":"u1"}, files={"file": ("resume.docx", docx_bytes(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document")})
    assert r.status_code == 202 and r.json()["status"] == "QUEUED"
    enqueue.assert_called_once()
def test_result_unavailable_until_completed(client):
    with patch("app.main.scan_with_clamav"), patch("app.main.parse_resume.delay"):
        r = client.post("/api/v1/resumes", headers={"X-User-ID":"u1"}, files={"file": ("resume.docx", docx_bytes(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document")})
    assert client.get(f"/api/v1/resumes/{r.json()['job_id']}/result", headers={"X-User-ID":"u1"}).status_code == 409
def test_queue_failure(client):
    with patch("app.main.scan_with_clamav"), patch("app.main.parse_resume.delay", side_effect=RuntimeError("broker down")):
        r = client.post("/api/v1/resumes", headers={"X-User-ID":"u1"}, files={"file": ("resume.docx", docx_bytes(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document")})
    assert r.status_code == 503
