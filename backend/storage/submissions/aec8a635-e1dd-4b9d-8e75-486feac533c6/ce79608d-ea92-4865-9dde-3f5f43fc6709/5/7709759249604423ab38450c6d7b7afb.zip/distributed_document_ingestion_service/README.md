# Distributed Resume Ingestion Service

## Run locally
1. `python -m venv .venv`
2. Activate the virtual environment and run `pip install -r requirements.txt`
3. Start Redis: `docker run --rm -p 6379:6379 redis:7`
4. API terminal: `uvicorn app.main:app --reload`
5. Worker terminal: `celery -A app.celery_app.celery_app worker --loglevel=INFO -Q resume_parsing`
6. Tests: `pytest --cov=app --cov-report=term-missing`

The default local database is SQLite for demo use. Set `DATABASE_URL` to PostgreSQL in deployment. Set `REQUIRE_CLAMAV=true` to fail closed if ClamAV is unavailable; install `clamscan` to scan files.

IMPORTANT: `X-User-ID` is a demo authentication placeholder, not production authentication. Replace it with verified JWT/session auth. The rate limiter is process-local; use a shared Redis-backed limiter for multi-worker deployments. Verify broker/DLQ integration and coverage locally before claiming production readiness.
