import os
class Settings:
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./ingestion.db")
    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    UPLOAD_DIR = os.getenv("UPLOAD_DIR", "./uploads")
    MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", str(10 * 1024 * 1024)))
    RATE_LIMIT_PER_MINUTE = int(os.getenv("RATE_LIMIT_PER_MINUTE", "10"))
    REQUIRE_CLAMAV = os.getenv("REQUIRE_CLAMAV", "false").lower() == "true"
settings = Settings()
