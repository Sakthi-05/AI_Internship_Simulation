import os
os.environ["DATABASE_URL"] = "sqlite:///./test_ingestion.db"
os.environ["UPLOAD_DIR"] = "./test_uploads"
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.database import Base, engine
@pytest.fixture(autouse=True)
def clean_db():
    Base.metadata.drop_all(bind=engine); Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)
@pytest.fixture
def client(): return TestClient(app)
