import os, uuid, time
from collections import defaultdict, deque
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from app.config import settings
from app.database import Base, engine, get_db
from app.models import ResumeJob
from app.security import safe_extension, detect_type, scan_with_clamav
from app.tasks import parse_resume
app = FastAPI(title="Distributed Resume Ingestion Service", version="1.0.0")
Base.metadata.create_all(bind=engine)
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
# Demo auth placeholder. Replace with verified JWT/session auth in production.
def current_user(x_user_id: str = Header(default="")):
    if not x_user_id.strip(): raise HTTPException(401, "Authentication required")
    return x_user_id.strip()
_buckets = defaultdict(deque)
def enforce_rate_limit(user_id):
    now = time.time(); bucket = _buckets[user_id]
    while bucket and now - bucket[0] >= 60: bucket.popleft()
    if len(bucket) >= settings.RATE_LIMIT_PER_MINUTE: raise HTTPException(429, "Upload rate limit exceeded")
    bucket.append(now)
@app.get("/health")
def health(): return {"status": "ok"}
@app.post("/api/v1/resumes", status_code=202)
async def upload_resume(file: UploadFile = File(...), user_id: str = Depends(current_user), db: Session = Depends(get_db)):
    enforce_rate_limit(user_id)
    ext = safe_extension(file.filename or "")
    data = await file.read(settings.MAX_UPLOAD_BYTES + 1)
    if not data: raise HTTPException(400, "Empty upload")
    if len(data) > settings.MAX_UPLOAD_BYTES: raise HTTPException(413, "File exceeds maximum upload size")
    mime = detect_type(data, ext)
    client_mime = (file.content_type or "").split(";")[0].strip().lower()
    if client_mime and client_mime not in {mime, "application/octet-stream"}:
        raise HTTPException(415, "Declared MIME type does not match file")
    job_id = str(uuid.uuid4()); path = os.path.join(settings.UPLOAD_DIR, job_id + ext)
    with open(path, "xb") as out: out.write(data)
    try:
        scan_with_clamav(path)
        job = ResumeJob(id=job_id, owner_id=user_id, object_key=path,
            original_filename=Path(file.filename or "resume").name[:255],
            detected_mime_type=mime, file_size_bytes=len(data), status="QUEUED")
        db.add(job); db.commit()
        try: parse_resume.delay(job_id)
        except Exception:
            job.status = "QUEUE_PENDING"; job.error_code = "BROKER_UNAVAILABLE"; db.commit()
            raise HTTPException(503, "Queue unavailable; job saved for safe retry")
        return {"job_id": job_id, "status": "QUEUED", "status_url": f"/api/v1/resumes/{job_id}"}
    except HTTPException:
        if os.path.exists(path): os.remove(path)
        raise
    except Exception:
        if os.path.exists(path): os.remove(path)
        raise HTTPException(500, "Unable to accept upload")
def owned_job(job_id, user_id, db):
    job = db.query(ResumeJob).filter(ResumeJob.id == job_id, ResumeJob.owner_id == user_id).first()
    if not job: raise HTTPException(404, "Resume job not found")
    return job
@app.get("/api/v1/resumes/{job_id}")
def resume_status(job_id: str, user_id: str = Depends(current_user), db: Session = Depends(get_db)):
    job = owned_job(job_id, user_id, db)
    return {"job_id": job.id, "status": job.status, "attempt_count": job.attempt_count, "error_code": job.error_code}
@app.get("/api/v1/resumes/{job_id}/result")
def resume_result(job_id: str, user_id: str = Depends(current_user), db: Session = Depends(get_db)):
    job = owned_job(job_id, user_id, db)
    if job.status != "COMPLETED": raise HTTPException(409, detail={"status": job.status, "error_code": job.error_code})
    return {"job_id": job.id, "text": job.result_text, "mime_type": job.detected_mime_type}
