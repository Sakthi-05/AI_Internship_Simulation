from celery import Celery
from app.config import settings
celery_app = Celery("document_ingestion", broker=settings.REDIS_URL, backend=settings.REDIS_URL)
celery_app.conf.update(
    task_serializer="json", accept_content=["json"], result_serializer="json",
    task_acks_late=True, worker_prefetch_multiplier=1, task_reject_on_worker_lost=True,
    task_routes={"app.tasks.parse_resume": {"queue": "resume_parsing"}},
    task_default_queue="resume_parsing",
    task_queues=None,
    task_create_missing_queues=True,
)
