import uuid
from sqlalchemy import Column, String, Integer, Text, DateTime
from sqlalchemy.sql import func
from app.database import Base
class ResumeJob(Base):
    __tablename__ = "resume_jobs"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    owner_id = Column(String(128), nullable=False, index=True)
    object_key = Column(String(512), nullable=False)
    original_filename = Column(String(255), nullable=False)
    detected_mime_type = Column(String(100), nullable=False)
    file_size_bytes = Column(Integer, nullable=False)
    status = Column(String(32), nullable=False, default="QUEUED", index=True)
    attempt_count = Column(Integer, nullable=False, default=0)
    result_text = Column(Text, nullable=True)
    error_code = Column(String(100), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    completed_at = Column(DateTime(timezone=True), nullable=True)
