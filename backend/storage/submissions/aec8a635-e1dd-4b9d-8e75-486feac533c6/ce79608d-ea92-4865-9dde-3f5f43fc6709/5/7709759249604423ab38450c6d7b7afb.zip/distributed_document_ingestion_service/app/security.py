import shutil, subprocess, io, zipfile
from pathlib import Path
from fastapi import HTTPException
from app.config import settings
PDF_MIME = "application/pdf"
DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
def safe_extension(filename):
    ext = Path(filename or "").suffix.lower()
    if ext not in {".pdf", ".docx"}: raise HTTPException(415, "Only PDF and DOCX files are supported")
    return ext
def detect_type(data, ext):
    if ext == ".pdf":
        if not data.startswith(b"%PDF-"): raise HTTPException(415, "File signature does not match PDF")
        return PDF_MIME
    if not data.startswith(b"PK\\x03\\x04"): raise HTTPException(415, "File signature does not match DOCX")
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = set(zf.namelist())
            if "[Content_Types].xml" not in names or "word/document.xml" not in names:
                raise HTTPException(415, "Invalid DOCX package")
            if zf.testzip(): raise HTTPException(400, "Corrupted DOCX file")
    except zipfile.BadZipFile: raise HTTPException(400, "Corrupted DOCX file")
    return DOCX_MIME
def scan_with_clamav(path):
    scanner = shutil.which("clamscan")
    if not scanner:
        if settings.REQUIRE_CLAMAV: raise HTTPException(503, "Malware scanner is unavailable")
        return
    result = subprocess.run([scanner, "--no-summary", path], capture_output=True, text=True, timeout=20)
    if result.returncode == 1: raise HTTPException(400, "File failed malware scan")
    if result.returncode != 0: raise HTTPException(503, "Malware scan could not complete")
def extract_text(path, mime):
    if mime == PDF_MIME:
        from pypdf import PdfReader
        reader = PdfReader(path)
        if reader.is_encrypted and reader.decrypt("") == 0: raise ValueError("Encrypted PDF")
        text = "\\n".join(page.extract_text() or "" for page in reader.pages)
    else:
        from docx import Document
        text = "\\n".join(p.text for p in Document(path).paragraphs)
    if not text.strip(): raise ValueError("No extractable text found")
    return text
