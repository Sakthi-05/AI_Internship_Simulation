from datetime import datetime, timezone
from app.celery_app import celery_app
from app.database import SessionLocal
from app.models import ResumeJob
from app.security import extract_text
@celery_app.task(bind=True, name="app.tasks.parse_resume", max_retries=2, acks_late=True)
def parse_resume(self, job_id):
    db = SessionLocal()
    try:
        job = db.query(ResumeJob).filter(ResumeJob.id == job_id).first()
        if not job: return {"status": "missing"}
        if job.status == "COMPLETED": return {"status": "COMPLETED", "job_id": job_id}
        job.status = "PROCESSING"; job.attempt_count = int(job.attempt_count or 0) + 1; db.commit()
        try:
            job.result_text = extract_text(job.object_key, job.detected_mime_type)
            job.status = "COMPLETED"; job.error_code = None; job.completed_at = datetime.now(timezone.utc)
            db.commit()
            return {"status": "COMPLETED", "job_id": job_id}
        except (OSError, TimeoutError) as exc:
            db.rollback()
            if self.request.retries < self.max_retries:
                raise self.retry(exc=exc, countdown=2 ** (self.request.retries + 1))
            job = db.query(ResumeJob).filter(ResumeJob.id == job_id).first()
            if job: job.status = "DEAD_LETTERED"; job.error_code = "TRANSIENT_FAILURE_EXHAUSTED"; db.commit()
            raise
        except Exception:
            db.rollback()
            job = db.query(ResumeJob).filter(ResumeJob.id == job_id).first()
            if job: job.status = "FAILED"; job.error_code = "DOCUMENT_PARSE_FAILED"; db.commit()
            raise
    finally: db.close()
@celery_app.task(name="app.tasks.dlq_record")
def dlq_record(job_id, error_code="TASK_FAILED"):
    db = SessionLocal()
    try:
        job = db.query(ResumeJob).filter(ResumeJob.id == job_id).first()
        if job and job.status != "COMPLETED":
            job.status = "DEAD_LETTERED"; job.error_code = error_code; db.commit()
    finally: db.close()


# Route failed parse jobs to a separate Celery queue for operator inspection.
from celery.signals import task_failure

@task_failure.connect
def route_parse_failure_to_dlq(sender=None, task_id=None, exception=None, args=None, kwargs=None, einfo=None, **extra):
    if getattr(sender, "name", None) == "app.tasks.parse_resume":
        job_id = (args or [None])[0]
        if job_id:
            dlq_record.apply_async(
                args=[job_id, "TASK_FAILED"],
                queue="resume_dlq",
            )
