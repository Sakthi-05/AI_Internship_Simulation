import os, uuid
from pathlib import Path
from typing import List
from fastapi import APIRouter, File, HTTPException, UploadFile
from celery.result import AsyncResult
from app.workers.celery_app import celery_app
from app.workers.tasks import parse_documents
from app.utils.validation import validate_upload
router = APIRouter(tags=["documents"])
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "uploads"))
@router.post("/documents/upload", status_code=202)
async def upload_documents(files: List[UploadFile] = File(...)):
    if not files: raise HTTPException(400, "At least one file is required")
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True); saved=[]
    try:
        for upload in files:
            data=await upload.read()
            try: validate_upload(upload.filename or "", upload.content_type or "", data)
            except ValueError as e: raise HTTPException(400, str(e)) from e
            name=f"{uuid.uuid4().hex}_{Path(upload.filename).name}"
            path=UPLOAD_DIR/name; path.write_bytes(data)
            saved.append({"path":str(path),"filename":Path(upload.filename).name})
        task=parse_documents.delay(saved)
        return {"task_id":task.id,"status":"QUEUED","documents_received":len(saved)}
    except Exception:
        for item in saved: Path(item["path"]).unlink(missing_ok=True)
        raise
@router.get("/documents/{task_id}/status")
def document_status(task_id: str):
    r=AsyncResult(task_id, app=celery_app)
    state={"PENDING":"QUEUED","STARTED":"PROCESSING","SUCCESS":"COMPLETED","FAILURE":"FAILED"}.get(r.state,r.state)
    return {"task_id":task_id,"status":state}
@router.get("/documents/{task_id}/result")
def document_result(task_id: str):
    r=AsyncResult(task_id, app=celery_app)
    if not r.ready(): raise HTTPException(409,"Document processing is not complete")
    if r.failed(): raise HTTPException(500,"Document processing failed")
    return {"task_id":task_id,"status":"COMPLETED","documents":r.result}
