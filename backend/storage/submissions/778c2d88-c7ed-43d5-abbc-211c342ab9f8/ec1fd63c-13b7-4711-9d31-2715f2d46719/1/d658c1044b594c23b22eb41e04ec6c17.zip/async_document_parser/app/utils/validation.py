from pathlib import Path
MAX_FILE_BYTES=15*1024*1024
MIME={".pdf":{"application/pdf","application/octet-stream"},".docx":{"application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/octet-stream"}}
def validate_upload(filename, content_type, content):
    ext=Path(filename).suffix.lower()
    if ext not in MIME: raise ValueError("Only PDF and DOCX files are supported")
    if not content: raise ValueError("Uploaded file is empty")
    if len(content)>MAX_FILE_BYTES: raise ValueError("File exceeds the 15 MB limit")
    if content_type and content_type not in MIME[ext]: raise ValueError("Content type does not match file extension")
    if ext==".pdf" and not content.startswith(b"%PDF"): raise ValueError("Invalid PDF file signature")
    if ext==".docx" and not content.startswith(b"PK"): raise ValueError("Invalid DOCX file signature")
