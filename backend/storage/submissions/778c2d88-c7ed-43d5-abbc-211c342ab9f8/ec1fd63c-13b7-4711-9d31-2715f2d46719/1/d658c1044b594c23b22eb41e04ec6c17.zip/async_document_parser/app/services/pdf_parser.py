import fitz
def extract_pdf(path):
    pages=[]
    with fitz.open(path) as doc:
        for n,page in enumerate(doc,1): pages.append({"page":n,"text":page.get_text("text")})
        meta=doc.metadata or {}
        return {"text":"\n".join(p["text"] for p in pages).strip(),"pages":pages,
                "metadata":{"page_count":len(doc),"title":meta.get("title"),"author":meta.get("author")}}
