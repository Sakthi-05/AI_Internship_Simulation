from docx import Document
def extract_docx(path):
    doc=Document(path); paragraphs=[p.text.strip() for p in doc.paragraphs if p.text.strip()]
    tables=[[[c.text.strip() for c in row.cells] for row in t.rows] for t in doc.tables]
    return {"text":"\n".join(paragraphs),"paragraphs":paragraphs,"tables":tables,
            "metadata":{"paragraph_count":len(paragraphs),"table_count":len(tables)}}
