import pytest
from app.utils.validation import validate_upload
def test_pdf_valid(): validate_upload("a.pdf","application/pdf",b"%PDF-1.7")
def test_docx_valid(): validate_upload("a.docx","application/vnd.openxmlformats-officedocument.wordprocessingml.document",b"PKdata")
@pytest.mark.parametrize("n,m,d",[("a.txt","text/plain",b"x"),("a.pdf","application/pdf",b"x"),("a.docx","application/pdf",b"PK"),("a.pdf","application/pdf",b"")])
def test_invalid(n,m,d):
    with pytest.raises(ValueError): validate_upload(n,m,d)
