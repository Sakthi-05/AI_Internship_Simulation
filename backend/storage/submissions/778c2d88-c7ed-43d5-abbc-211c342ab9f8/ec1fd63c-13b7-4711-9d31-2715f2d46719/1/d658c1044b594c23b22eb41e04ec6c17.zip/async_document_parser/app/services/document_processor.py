from pathlib import Path
from app.services.pdf_parser import extract_pdf
from app.services.docx_parser import extract_docx
ALIASES={"experience":{"experience","employment","work history"},"education":{"education","academic","qualification"},
         "skills":{"skills","technical skills","technologies"},"projects":{"projects","project experience"}}
def detect_sections(text):
    result={}; current="other"
    for line in (x.strip() for x in text.splitlines() if x.strip()):
        match=next((k for k,v in ALIASES.items() if line.lower().rstrip(":") in v),None)
        if match: current=match; result.setdefault(current,[])
        else: result.setdefault(current,[]).append(line)
    return {k:"\n".join(v) for k,v in result.items()}
def parse_document(path, filename):
    ext=Path(filename).suffix.lower()
    if ext==".pdf": data=extract_pdf(path)
    elif ext==".docx": data=extract_docx(path)
    else: raise ValueError("Unsupported document format")
    data["sections"]=detect_sections(data.get("text","")); data["filename"]=filename
    return data
