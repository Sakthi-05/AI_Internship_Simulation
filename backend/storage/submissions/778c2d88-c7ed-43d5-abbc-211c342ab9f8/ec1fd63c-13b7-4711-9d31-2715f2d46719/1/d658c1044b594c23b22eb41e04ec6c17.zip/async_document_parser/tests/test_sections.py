from app.services.document_processor import detect_sections
def test_sections():
    x=detect_sections("Name\nExperience\nDeveloper\nEducation\nBSc\nSkills\nPython")
    assert x["experience"]=="Developer" and x["education"]=="BSc" and x["skills"]=="Python"
def test_empty(): assert detect_sections("")=={}
