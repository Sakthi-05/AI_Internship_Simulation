# Asynchronous Document Parsing Pipeline

FastAPI + Celery + Redis service for asynchronous PDF and DOCX parsing.

## Setup (PowerShell)
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
docker compose up -d redis
```
Open three terminals in the project directory.

API:
```powershell
.\.venv\Scripts\Activate.ps1
uvicorn app.main:app --reload
```
Worker:
```powershell
.\.venv\Scripts\Activate.ps1
celery -A app.workers.celery_app.celery_app worker --loglevel=info --pool=solo
```
Tests:
```powershell
pytest -q
pytest --cov=app --cov-report=term-missing
```

## Endpoints
- `GET /health`
- `POST /api/documents/upload` (multipart field `files`, multiple PDF/DOCX)
- `GET /api/documents/{task_id}/status`
- `GET /api/documents/{task_id}/result`

Docs: http://localhost:8000/docs

## Flow
Upload validates files, stores them temporarily, enqueues Celery work and returns a task ID. Worker extracts text and basic resume sections; Redis stores task state/result.

## Production hardening
Add authentication, malware scanning, private object storage, durable metadata, rate limits and retention policies. Section detection is heuristic. For multi-instance deployments, use shared object storage accessible by workers. Coverage must be measured; do not claim the 85% criterion unless the actual report meets it.
