import logging
from pathlib import Path
from app.workers.celery_app import celery_app
from app.services.document_processor import parse_document
log=logging.getLogger(__name__)
@celery_app.task(bind=True,name="parse_documents")
def parse_documents(self, files):
    output=[]
    for item in files:
        path=Path(item["path"])
        try: output.append({"status":"COMPLETED",**parse_document(str(path),item["filename"])})
        except Exception:
            log.exception("document_parse_failed task_id=%s filename=%s",self.request.id,item.get("filename"))
            output.append({"status":"FAILED","filename":item.get("filename","unknown"),"error":"Document could not be parsed"})
        finally: path.unlink(missing_ok=True)
    return output
