"""
Concurrent Chunk Ingestion Service
----------------------------------
FastAPI + Redis + PostgreSQL implementation.

Environment variables:
  DATABASE_URL      postgresql+asyncpg://postgres:postgres@localhost:5432/ai_internship
  REDIS_URL         redis://localhost:6379/0
  CHUNK_STORAGE     ./chunk_storage

Run:
  uvicorn solution:app --reload --port 8000
"""

import os
import re
import uuid
import hashlib
import asyncio
from pathlib import Path
from typing import List

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from redis.asyncio import Redis
from sqlalchemy import String, Integer
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


# ---------------- Configuration ----------------

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+asyncpg://postgres:postgres@localhost:5432/ai_internship",
)
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

STORAGE = Path(os.getenv("CHUNK_STORAGE", "./chunk_storage"))
TEMP_DIR = STORAGE / "chunks"
FINAL_DIR = STORAGE / "completed"

MAX_CHUNK_SIZE = 10 * 1024 * 1024
MAX_TOTAL_CHUNKS = 10000
LOCK_TIMEOUT_SECONDS = 600
LOCK_WAIT_SECONDS = 30
UPLOAD_STATE_TTL_SECONDS = 24 * 60 * 60

TEMP_DIR.mkdir(parents=True, exist_ok=True)
FINAL_DIR.mkdir(parents=True, exist_ok=True)


# ---------------- Database ----------------

class Base(DeclarativeBase):
    pass


class CompletedUpload(Base):
    __tablename__ = "completed_uploads"

    file_id: Mapped[str] = mapped_column(String(100), primary_key=True)
    total_chunks: Mapped[int] = mapped_column(Integer, nullable=False)
    storage_path: Mapped[str] = mapped_column(String(500), nullable=False)


engine = create_async_engine(DATABASE_URL, pool_pre_ping=True)
Session = async_sessionmaker(engine, expire_on_commit=False)

redis = Redis.from_url(REDIS_URL, decode_responses=True)

app = FastAPI(title="Concurrent Chunk Ingestion Service")


@app.on_event("startup")
async def startup():
    """Create the table for this standalone exercise."""
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)
    await redis.ping()


@app.on_event("shutdown")
async def shutdown():
    await redis.aclose()
    await engine.dispose()


# ---------------- Storage helpers ----------------

def save_chunk(content: bytes, checksum: str) -> Path:
    """
    Persist a verified chunk under its SHA-256 digest.
    The temporary file + os.replace pattern avoids exposing partial files.
    """
    actual = hashlib.sha256(content).hexdigest()
    if actual != checksum.lower():
        raise ValueError("Chunk content does not match its SHA-256 key")

    destination = TEMP_DIR / actual
    if destination.exists():
        # A digest-named object must contain the bytes represented by its name.
        existing_digest = hashlib.sha256(destination.read_bytes()).hexdigest()
        if existing_digest == actual:
            return destination

    temporary = TEMP_DIR / f"{uuid.uuid4().hex}.tmp"
    try:
        with open(temporary, "wb") as output:
            output.write(content)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)

    return destination


def assemble_file(file_id: str, hashes: List[str]) -> Path:
    """Assemble chunks in index order and atomically publish the completed file."""
    destination = FINAL_DIR / f"{file_id}.complete"
    temporary = FINAL_DIR / f"{uuid.uuid4().hex}.tmp"

    try:
        with open(temporary, "wb") as output:
            for digest in hashes:
                if not re.fullmatch(r"[a-f0-9]{64}", digest):
                    raise ValueError("Invalid chunk digest in upload state")

                chunk_path = TEMP_DIR / digest
                if not chunk_path.is_file():
                    raise FileNotFoundError(f"Missing chunk: {digest}")

                # Re-verify stored content before including it in the final file.
                hasher = hashlib.sha256()
                with open(chunk_path, "rb") as source:
                    while True:
                        block = source.read(1024 * 1024)
                        if not block:
                            break
                        hasher.update(block)
                        output.write(block)

                if hasher.hexdigest() != digest:
                    raise ValueError(f"Stored chunk failed integrity check: {digest}")

            output.flush()
            os.fsync(output.fileno())

        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)

    return destination


# ---------------- Upload endpoint ----------------

@app.post("/api/chunks/upload")
async def upload_chunk(
    file: UploadFile = File(...),
    file_id: str = Form(...),
    chunk_index: int = Form(...),
    total_chunks: int = Form(...),
    checksum: str = Form(...),
):
    """
    Receive one multipart chunk.

    A Redis distributed lock serializes updates for a particular file ID.
    Different file IDs can progress independently.
    """
    # Validate metadata before reading or persisting the payload.
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", file_id):
        raise HTTPException(status_code=400, detail="Invalid file ID")

    if not 1 <= total_chunks <= MAX_TOTAL_CHUNKS:
        raise HTTPException(status_code=400, detail="Invalid total chunk count")

    if not 0 <= chunk_index < total_chunks:
        raise HTTPException(status_code=400, detail="Invalid chunk index")

    if not re.fullmatch(r"[a-fA-F0-9]{64}", checksum):
        raise HTTPException(status_code=400, detail="Invalid SHA-256 checksum")

    try:
        content = await file.read(MAX_CHUNK_SIZE + 1)
        if len(content) > MAX_CHUNK_SIZE:
            raise HTTPException(status_code=413, detail="Chunk exceeds maximum size")

        actual_hash = hashlib.sha256(content).hexdigest()
        if actual_hash != checksum.lower():
            raise HTTPException(status_code=400, detail="SHA-256 checksum mismatch")

        checksum = actual_hash
        state_key = f"upload:{file_id}"
        received_key = f"{state_key}:received"
        lock_key = f"upload-lock:{file_id}"

        lock = redis.lock(
            lock_key,
            timeout=LOCK_TIMEOUT_SECONDS,
            blocking_timeout=LOCK_WAIT_SECONDS,
        )

        try:
            async with lock:
                # Idempotent response if this file has already completed.
                async with Session() as db:
                    completed = await db.get(CompletedUpload, file_id)
                    if completed is not None:
                        return {
                            "status": "completed",
                            "file_id": file_id,
                            "received_chunks": completed.total_chunks,
                            "total_chunks": completed.total_chunks,
                            "storage_path": completed.storage_path,
                        }

                # Establish and enforce a stable manifest for this upload.
                stored_total = await redis.hget(state_key, "total_chunks")
                if stored_total is not None:
                    if int(stored_total) != total_chunks:
                        raise HTTPException(
                            status_code=409,
                            detail="Total chunk count mismatch",
                        )
                else:
                    await redis.hset(
                        state_key,
                        mapping={
                            "total_chunks": str(total_chunks),
                            "status": "uploading",
                        },
                    )

                old_hash = await redis.hget(state_key, f"chunk:{chunk_index}")
                if old_hash is not None and old_hash != checksum:
                    raise HTTPException(
                        status_code=409,
                        detail="Chunk index already contains different data",
                    )

                # Store by digest; identical content is stored only once.
                await asyncio.to_thread(save_chunk, content, checksum)

                # Hash field maps index -> digest; Redis set tracks unique indexes.
                await redis.hset(state_key, f"chunk:{chunk_index}", checksum)
                await redis.sadd(received_key, str(chunk_index))
                await redis.expire(state_key, UPLOAD_STATE_TTL_SECONDS)
                await redis.expire(received_key, UPLOAD_STATE_TTL_SECONDS)

                received_count = await redis.scard(received_key)

                if received_count < total_chunks:
                    return {
                        "status": "uploading",
                        "file_id": file_id,
                        "received_chunks": received_count,
                        "total_chunks": total_chunks,
                        "missing_chunks": total_chunks - received_count,
                    }

                # Read hashes in exact numeric chunk order, not arrival order.
                fields = [f"chunk:{index}" for index in range(total_chunks)]
                hashes = await redis.hmget(state_key, fields)

                if len(hashes) != total_chunks or any(value is None for value in hashes):
                    raise HTTPException(
                        status_code=409,
                        detail="Incomplete chunk metadata",
                    )

                final_path = await asyncio.to_thread(
                    assemble_file,
                    file_id,
                    hashes,
                )

                # Persist completion using fully awaited async SQLAlchemy calls.
                async with Session() as db:
                    completed = await db.get(CompletedUpload, file_id)
                    if completed is None:
                        db.add(
                            CompletedUpload(
                                file_id=file_id,
                                total_chunks=total_chunks,
                                storage_path=str(final_path),
                            )
                        )
                    await db.commit()

                await redis.hset(
                    state_key,
                    mapping={
                        "status": "completed",
                        "storage_path": str(final_path),
                    },
                )

                return {
                    "status": "completed",
                    "file_id": file_id,
                    "received_chunks": received_count,
                    "total_chunks": total_chunks,
                    "storage_path": str(final_path),
                }

        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(
                status_code=500,
                detail=f"Chunk ingestion failed: {type(exc).__name__}: {exc}",
            ) from exc

    finally:
        await file.close()


@app.get("/api/chunks/{file_id}/status")
async def upload_status(file_id: str):
    """Return the distributed progress state for an upload."""
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", file_id):
        raise HTTPException(status_code=400, detail="Invalid file ID")

    state_key = f"upload:{file_id}"
    state = await redis.hgetall(state_key)

    if not state:
        async with Session() as db:
            completed = await db.get(CompletedUpload, file_id)
            if completed is None:
                raise HTTPException(status_code=404, detail="Upload not found")
            return {
                "status": "completed",
                "file_id": file_id,
                "total_chunks": completed.total_chunks,
                "storage_path": completed.storage_path,
            }

    total = int(state.get("total_chunks", "0"))
    received = await redis.scard(f"{state_key}:received")

    return {
        "status": state.get("status", "uploading"),
        "file_id": file_id,
        "received_chunks": received,
        "total_chunks": total,
        "missing_chunks": max(total - received, 0),
        "storage_path": state.get("storage_path"),
    }
