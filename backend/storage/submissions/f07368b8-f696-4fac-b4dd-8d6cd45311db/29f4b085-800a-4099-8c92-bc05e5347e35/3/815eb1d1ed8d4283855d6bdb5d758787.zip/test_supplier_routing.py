import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from supplier_routing import (
    Base, Warehouse, Supplier, SupplierOffer, RoutingDecision,
    create_app,
)


@pytest.fixture
def setup():
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    app = create_app(db_engine=engine, create_tables=False)
    with TestClient(app) as client:
        yield client, factory
    engine.dispose()


def seed_offer(factory, supplier_code, tier, warehouse_code, qty,
               cost, lead, reliability=90, sku="SKU-1", active=True):
    with factory() as db:
        warehouse = db.execute(
            select(Warehouse).where(Warehouse.code == warehouse_code)
        ).scalar_one_or_none()
        if warehouse is None:
            warehouse = Warehouse(code=warehouse_code, name=warehouse_code,
                                  region="North", active=True)
            db.add(warehouse)
            db.flush()

        supplier = db.execute(
            select(Supplier).where(Supplier.code == supplier_code)
        ).scalar_one_or_none()
        if supplier is None:
            supplier = Supplier(code=supplier_code, name=supplier_code,
                                tier=tier, reliability_score=reliability,
                                active=True)
            db.add(supplier)
            db.flush()

        db.add(SupplierOffer(
            supplier_id=supplier.id,
            warehouse_id=warehouse.id,
            sku=sku,
            available_qty=qty,
            unit_cost=cost,
            lead_time_hours=lead,
            active=active,
        ))
        db.commit()


def payload(quantity=10, max_lead=72, allow_split=True):
    return {
        "requisition_ref": "REQ-100",
        "sku": "SKU-1",
        "quantity": quantity,
        "max_lead_time_hours": max_lead,
        "allow_split": allow_split,
    }


def test_health(setup):
    client, _ = setup
    assert client.get("/health").json()["status"] == "healthy"


def test_best_primary_supplier_selected(setup):
    client, factory = setup
    seed_offer(factory, "SUP-P", "PRIMARY", "WH-A", 50, 10, 24, 95)
    seed_offer(factory, "SUP-S", "SECONDARY", "WH-B", 50, 12, 36, 90)
    response = client.post("/routing/evaluate", json=payload())
    assert response.status_code == 200
    data = response.json()
    assert data["primary_supplier"] == "SUP-P"
    assert data["allocated_qty"] == 10
    assert data["status"] == "FULLY_ROUTED"


def test_secondary_fallback_when_primary_has_no_stock(setup):
    client, factory = setup
    seed_offer(factory, "SUP-S", "SECONDARY", "WH-B", 20, 12, 24)
    response = client.post("/routing/evaluate", json=payload())
    assert response.status_code == 200
    assert response.json()["primary_supplier"] == "SUP-S"
    assert response.json()["fallback_used"] is True


def test_latency_threshold_excludes_slow_supplier(setup):
    client, factory = setup
    seed_offer(factory, "SUP-SLOW", "PRIMARY", "WH-A", 100, 5, 96)
    seed_offer(factory, "SUP-FAST", "SECONDARY", "WH-B", 20, 15, 12)
    response = client.post("/routing/evaluate", json=payload(max_lead=24))
    assert response.status_code == 200
    assert response.json()["primary_supplier"] == "SUP-FAST"


def test_no_supplier_within_latency_returns_404(setup):
    client, factory = setup
    seed_offer(factory, "SUP-SLOW", "PRIMARY", "WH-A", 100, 5, 96)
    response = client.post("/routing/evaluate", json=payload(max_lead=24))
    assert response.status_code == 404


def test_multi_supplier_split_fulfills_requisition(setup):
    client, factory = setup
    seed_offer(factory, "SUP-A", "PRIMARY", "WH-A", 6, 10, 12)
    seed_offer(factory, "SUP-B", "SECONDARY", "WH-B", 8, 11, 18)
    response = client.post("/routing/evaluate", json=payload(quantity=10))
    assert response.status_code == 200
    data = response.json()
    assert data["allocated_qty"] == 10
    assert len(data["allocations"]) == 2
    assert sum(a["quantity"] for a in data["allocations"]) == 10


def test_partial_route_when_total_stock_is_insufficient(setup):
    client, factory = setup
    seed_offer(factory, "SUP-A", "PRIMARY", "WH-A", 4, 10, 12)
    response = client.post("/routing/evaluate", json=payload(quantity=10))
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "PARTIALLY_ROUTED"
    assert data["allocated_qty"] == 4
    assert data["unfilled_qty"] == 6


def test_no_split_uses_only_best_offer(setup):
    client, factory = setup
    seed_offer(factory, "SUP-A", "PRIMARY", "WH-A", 4, 10, 12)
    seed_offer(factory, "SUP-B", "SECONDARY", "WH-B", 20, 11, 18)
    response = client.post("/routing/evaluate", json=payload(quantity=10, allow_split=False))
    assert response.status_code == 200
    assert response.json()["allocated_qty"] == 4
    assert len(response.json()["allocations"]) == 1


def test_no_active_or_available_offer_returns_404(setup):
    client, factory = setup
    seed_offer(factory, "SUP-A", "PRIMARY", "WH-A", 0, 10, 12)
    response = client.post("/routing/evaluate", json=payload())
    assert response.status_code == 404


def test_inactive_offer_is_ignored(setup):
    client, factory = setup
    seed_offer(factory, "SUP-INACTIVE", "PRIMARY", "WH-A", 20, 5, 12, active=False)
    response = client.post("/routing/evaluate", json=payload())
    assert response.status_code == 404


def test_invalid_zero_quantity_rejected(setup):
    client, _ = setup
    response = client.post("/routing/evaluate", json=payload(quantity=0))
    assert response.status_code == 422


def test_invalid_negative_lead_time_rejected(setup):
    client, _ = setup
    response = client.post("/routing/evaluate", json=payload(max_lead=-1))
    assert response.status_code == 422


def test_decision_is_persisted(setup):
    client, factory = setup
    seed_offer(factory, "SUP-A", "PRIMARY", "WH-A", 20, 10, 12)
    response = client.post("/routing/evaluate", json=payload())
    assert response.status_code == 200
    with factory() as db:
        decisions = db.query(RoutingDecision).all()
        assert len(decisions) == 1
        assert decisions[0].requisition_ref == "REQ-100"


def test_cost_can_outweigh_tier_preference(setup):
    client, factory = setup
    seed_offer(factory, "SUP-PRIMARY", "PRIMARY", "WH-A", 20, 100, 24, 80)
    seed_offer(factory, "SUP-SECONDARY", "SECONDARY", "WH-B", 20, 10, 24, 95)
    response = client.post("/routing/evaluate", json=payload())
    assert response.status_code == 200
    assert response.json()["primary_supplier"] == "SUP-SECONDARY"
    assert response.json()["fallback_used"] is True
