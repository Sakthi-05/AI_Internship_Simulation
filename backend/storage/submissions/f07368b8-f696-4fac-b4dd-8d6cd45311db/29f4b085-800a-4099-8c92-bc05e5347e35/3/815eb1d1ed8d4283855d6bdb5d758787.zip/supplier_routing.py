"""
Supplier Tiering & Multi-Warehouse Order Routing Service
========================================================
FastAPI + SQLAlchemy implementation for evaluating purchase requisitions.

Run:
    pip install -r requirements.txt
    uvicorn supplier_routing:app --reload

Tests:
    pytest -q

The default database is SQLite for a simple local demonstration. Set
DATABASE_URL to a PostgreSQL SQLAlchemy URL for PostgreSQL deployment.
Tables are created only when AUTO_CREATE_TABLES=true.
"""

import os
from datetime import datetime, timezone
from typing import Generator, Optional

from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel, Field, ConfigDict
from sqlalchemy import (
    Boolean, CheckConstraint, DateTime, Float, ForeignKey, Integer,
    String, UniqueConstraint, create_engine, select, Index
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker, Session


DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./supplier_routing.db")
AUTO_CREATE_TABLES = os.getenv("AUTO_CREATE_TABLES", "true").lower() == "true"

engine_kwargs = {"pool_pre_ping": True}
if DATABASE_URL.startswith("sqlite"):
    engine_kwargs["connect_args"] = {"check_same_thread": False}
engine = create_engine(DATABASE_URL, **engine_kwargs)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def utc_now():
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class Warehouse(Base):
    __tablename__ = "routing_warehouses"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    region: Mapped[str] = mapped_column(String(80), nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class Supplier(Base):
    __tablename__ = "routing_suppliers"
    __table_args__ = (
        CheckConstraint("reliability_score >= 0 AND reliability_score <= 100",
                        name="ck_supplier_reliability_range"),
        Index("ix_supplier_active_tier", "active", "tier"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    tier: Mapped[str] = mapped_column(String(20), default="SECONDARY", nullable=False)
    reliability_score: Mapped[float] = mapped_column(Float, default=80.0, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class SupplierOffer(Base):
    """A supplier's offer to fulfill one SKU from one warehouse."""
    __tablename__ = "supplier_offers"
    __table_args__ = (
        UniqueConstraint("supplier_id", "warehouse_id", "sku",
                         name="uq_supplier_warehouse_sku"),
        CheckConstraint("available_qty >= 0", name="ck_offer_qty_nonnegative"),
        CheckConstraint("unit_cost >= 0", name="ck_offer_cost_nonnegative"),
        CheckConstraint("lead_time_hours >= 0", name="ck_offer_lead_nonnegative"),
        Index("ix_offer_sku_warehouse", "sku", "warehouse_id"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    supplier_id: Mapped[int] = mapped_column(ForeignKey("routing_suppliers.id"), nullable=False)
    warehouse_id: Mapped[int] = mapped_column(ForeignKey("routing_warehouses.id"), nullable=False)
    sku: Mapped[str] = mapped_column(String(80), nullable=False)
    available_qty: Mapped[int] = mapped_column(Integer, nullable=False)
    unit_cost: Mapped[float] = mapped_column(Float, nullable=False)
    lead_time_hours: Mapped[float] = mapped_column(Float, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    supplier: Mapped[Supplier] = relationship()
    warehouse: Mapped[Warehouse] = relationship()


class RoutingDecision(Base):
    __tablename__ = "routing_decisions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    requisition_ref: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    sku: Mapped[str] = mapped_column(String(80), nullable=False)
    requested_qty: Mapped[int] = mapped_column(Integer, nullable=False)
    allocated_qty: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, nullable=False)


class RoutingAllocation(Base):
    __tablename__ = "routing_allocations"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    decision_id: Mapped[int] = mapped_column(ForeignKey("routing_decisions.id", ondelete="CASCADE"), nullable=False)
    supplier_id: Mapped[int] = mapped_column(ForeignKey("routing_suppliers.id"), nullable=False)
    warehouse_id: Mapped[int] = mapped_column(ForeignKey("routing_warehouses.id"), nullable=False)
    offer_id: Mapped[int] = mapped_column(ForeignKey("supplier_offers.id"), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    unit_cost: Mapped[float] = mapped_column(Float, nullable=False)
    lead_time_hours: Mapped[float] = mapped_column(Float, nullable=False)


class RequisitionRequest(BaseModel):
    requisition_ref: str = Field(min_length=1, max_length=80)
    sku: str = Field(min_length=1, max_length=80)
    quantity: int = Field(gt=0)
    max_lead_time_hours: float = Field(default=72, gt=0)
    allow_split: bool = True


class AllocationResponse(BaseModel):
    supplier_code: str
    supplier_name: str
    supplier_tier: str
    warehouse_code: str
    warehouse_name: str
    quantity: int
    unit_cost: float
    lead_time_hours: float
    score: float


class RoutingResponse(BaseModel):
    decision_id: int
    requisition_ref: str
    sku: str
    requested_qty: int
    allocated_qty: int
    unfilled_qty: int
    status: str
    primary_supplier: Optional[str]
    allocations: list[AllocationResponse]
    fallback_used: bool
    explanation: list[str]


class RoutingEngine:
    """
    Weighted decision model (lower score is better):
      45% landed unit cost, 30% lead time, 15% supplier reliability,
      10% supplier tier preference.

    Cost and lead time are normalized against the eligible candidate set.
    Reliability is converted to a penalty (100 - reliability).
    PRIMARY suppliers receive a tier penalty of 0; SECONDARY suppliers 20.
    Tier is a preference, not an absolute override: a materially better
    secondary offer can outrank a poor primary offer.
    """

    COST_WEIGHT = 0.45
    LEAD_WEIGHT = 0.30
    RELIABILITY_WEIGHT = 0.15
    TIER_WEIGHT = 0.10

    def __init__(self, db: Session):
        self.db = db

    def _candidates(self, sku: str, max_lead: float):
        rows = self.db.execute(
            select(SupplierOffer, Supplier, Warehouse)
            .join(Supplier, Supplier.id == SupplierOffer.supplier_id)
            .join(Warehouse, Warehouse.id == SupplierOffer.warehouse_id)
            .where(
                SupplierOffer.sku == sku,
                SupplierOffer.active.is_(True),
                Supplier.active.is_(True),
                Warehouse.active.is_(True),
                SupplierOffer.available_qty > 0,
            )
        ).all()

        # Offers over the latency threshold are excluded and can never be
        # selected as primary or fallback.
        return [
            (offer, supplier, warehouse)
            for offer, supplier, warehouse in rows
            if offer.lead_time_hours <= max_lead
        ]

    @staticmethod
    def _normal(value, low, high):
        if high == low:
            return 0.0
        return (value - low) / (high - low)

    def evaluate(self, request: RequisitionRequest) -> RoutingResponse:
        candidates = self._candidates(request.sku, request.max_lead_time_hours)
        if not candidates:
            raise HTTPException(
                status_code=404,
                detail="No active supplier offer has stock within the lead-time threshold.",
            )

        costs = [x[0].unit_cost for x in candidates]
        leads = [x[0].lead_time_hours for x in candidates]
        min_cost, max_cost = min(costs), max(costs)
        min_lead, max_lead = min(leads), max(leads)

        ranked = []
        for offer, supplier, warehouse in candidates:
            tier_penalty = 0 if supplier.tier.upper() == "PRIMARY" else 20
            score = (
                self.COST_WEIGHT * self._normal(offer.unit_cost, min_cost, max_cost) * 100
                + self.LEAD_WEIGHT * self._normal(offer.lead_time_hours, min_lead, max_lead) * 100
                + self.RELIABILITY_WEIGHT * (100 - supplier.reliability_score)
                + self.TIER_WEIGHT * tier_penalty
            )
            ranked.append((score, offer, supplier, warehouse))

        ranked.sort(key=lambda x: (x[0], x[1].unit_cost, x[1].lead_time_hours, x[2].code))

        remaining = request.quantity
        selected = []
        for score, offer, supplier, warehouse in ranked:
            if remaining <= 0:
                break
            if selected and not request.allow_split:
                break
            take = min(remaining, offer.available_qty)
            if take <= 0:
                continue
            selected.append((score, offer, supplier, warehouse, take))
            remaining -= take

        allocated = request.quantity - remaining
        if allocated == 0:
            raise HTTPException(status_code=409, detail="Eligible suppliers have no allocatable stock.")

        # Persist decision and allocations in one transaction. Offers are
        # treated as available-to-promise data; this records the decision.
        decision = RoutingDecision(
            requisition_ref=request.requisition_ref,
            sku=request.sku,
            requested_qty=request.quantity,
            allocated_qty=allocated,
            status="FULLY_ROUTED" if remaining == 0 else "PARTIALLY_ROUTED",
        )
        self.db.add(decision)
        self.db.flush()

        allocations = []
        for score, offer, supplier, warehouse, qty in selected:
            self.db.add(RoutingAllocation(
                decision_id=decision.id,
                supplier_id=supplier.id,
                warehouse_id=warehouse.id,
                offer_id=offer.id,
                quantity=qty,
                unit_cost=offer.unit_cost,
                lead_time_hours=offer.lead_time_hours,
            ))
            allocations.append(AllocationResponse(
                supplier_code=supplier.code,
                supplier_name=supplier.name,
                supplier_tier=supplier.tier,
                warehouse_code=warehouse.code,
                warehouse_name=warehouse.name,
                quantity=qty,
                unit_cost=offer.unit_cost,
                lead_time_hours=offer.lead_time_hours,
                score=round(score, 2),
            ))

        self.db.commit()
        self.db.refresh(decision)

        best = selected[0]
        explanation = [
            "Candidates were filtered by active status, positive stock, and the requested maximum lead time.",
            "Eligible offers were ranked using cost (45%), lead time (30%), reliability (15%), and tier preference (10%).",
        ]
        fallback_used = best[2].tier.upper() != "PRIMARY"
        if fallback_used:
            explanation.append("A secondary supplier was selected because it ranked ahead of available primary-tier offers.")
        if len(selected) > 1:
            explanation.append("The requisition was split across multiple eligible supplier/warehouse offers to cover demand.")
        if remaining:
            explanation.append(f"Only {allocated} of {request.quantity} units could be routed; {remaining} remain unfilled.")

        return RoutingResponse(
            decision_id=decision.id,
            requisition_ref=request.requisition_ref,
            sku=request.sku,
            requested_qty=request.quantity,
            allocated_qty=allocated,
            unfilled_qty=remaining,
            status=decision.status,
            primary_supplier=best[2].code,
            allocations=allocations,
            fallback_used=fallback_used,
            explanation=explanation,
        )


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_app(db_engine=None, create_tables=False):
    application = FastAPI(
        title="Supplier Tiering and Order Routing API",
        version="1.0.0",
        description="Evaluates requisitions and selects supplier/warehouse fulfillment routes.",
    )
    selected_engine = db_engine or engine
    factory = sessionmaker(bind=selected_engine, autoflush=False, expire_on_commit=False)

    def db_dependency():
        db = factory()
        try:
            yield db
        finally:
            db.close()

    if create_tables:
        @application.on_event("startup")
        def startup():
            Base.metadata.create_all(selected_engine)

    @application.get("/health")
    def health():
        return {"status": "healthy"}

    @application.post("/routing/evaluate", response_model=RoutingResponse)
    def evaluate_requisition(
        request: RequisitionRequest,
        db: Session = Depends(db_dependency),
    ):
        try:
            return RoutingEngine(db).evaluate(request)
        except HTTPException:
            db.rollback()
            raise
        except Exception:
            db.rollback()
            raise

    return application


app = create_app(create_tables=AUTO_CREATE_TABLES)
