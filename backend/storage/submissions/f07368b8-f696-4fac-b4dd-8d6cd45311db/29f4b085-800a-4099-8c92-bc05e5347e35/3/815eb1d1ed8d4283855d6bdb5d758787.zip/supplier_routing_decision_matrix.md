# Technical Decision Document
## Supplier Tiering & Multi-Warehouse Order Routing Strategy

**Project:** Enterprise Resource Planning (ERP) Internship Simulation  
**Component:** Supplier Tiering and Order Routing  
**Implementation:** Python, FastAPI, SQLAlchemy, PostgreSQL

## 1. Objective

Design a deterministic, explainable routing strategy that evaluates a purchase requisition and selects the best eligible supplier/warehouse fulfillment route. The strategy must balance landed unit cost, lead time, supplier reliability, supplier tier, and available stock. It must support fallback to secondary suppliers and splitting demand across multiple eligible offers.

## 2. Terminology and assumptions

- **Supplier tier:** Operational preference (`PRIMARY` or `SECONDARY`), maintained by procurement.
- **Supplier offer:** A supplier's available quantity of a SKU at a particular warehouse, with unit cost and estimated lead time.
- **Eligible offer:** An active supplier, active warehouse, active offer, positive available quantity, and lead time within the requisition's maximum.
- **Primary route:** The highest-ranked eligible offer. It may be supplied by a secondary-tier supplier if that supplier's overall score is better.
- **Fallback:** Selection of the next-ranked eligible offer when the preferred offer cannot cover all requested units, is unavailable, or violates the lead-time threshold.
- **Split fulfillment:** Allocating one requisition across multiple supplier/warehouse offers when permitted.

This implementation treats `available_qty` as available-to-promise input data. It records routing decisions and allocations; it does not decrement physical inventory or create purchase orders. Those actions should be performed by a subsequent procurement/inventory transaction.

## 3. Decision criteria

| Criterion | Weight | Evaluation |
|---|---:|---|
| Unit cost | 45% | Lower cost receives a better normalized score |
| Lead time | 30% | Shorter lead time receives a better normalized score |
| Supplier reliability | 15% | Higher reliability score receives a lower penalty |
| Supplier tier | 10% | PRIMARY receives preference over SECONDARY |

Lower total score is better. Cost and lead time are normalized against the eligible offers for the same requisition. Reliability is scored as `100 - reliability_score`. The tier penalty is 0 for PRIMARY and 20 for SECONDARY.

**Score formula**

`score = 0.45 × normalized_cost × 100 + 0.30 × normalized_lead_time × 100 + 0.15 × (100 - reliability_score) + 0.10 × tier_penalty`

Where:
- `normalized_cost = (offer_cost - minimum_cost) / (maximum_cost - minimum_cost)`
- `normalized_lead_time = (offer_lead - minimum_lead) / (maximum_lead - minimum_lead)`
- If all eligible candidates have the same cost or lead time, that criterion's normalized value is 0.
- `tier_penalty = 0` for PRIMARY and `20` for SECONDARY.

The tier is a preference rather than an unconditional override. A secondary supplier can be selected when its cost, lead time, and reliability produce a better total score.

## 4. Primary versus secondary routing matrix

| Situation | Routing decision | Reason |
|---|---|---|
| Primary supplier has sufficient stock and meets latency threshold | Rank and select it if its score is best | Preferred supplier is eligible |
| Primary supplier has zero stock | Exclude it; evaluate secondary suppliers | No fulfillable quantity |
| Primary supplier has partial stock | Allocate available quantity, then evaluate next-ranked offer if splitting is allowed | Avoid unnecessary unfilled demand |
| Primary supplier exceeds maximum lead time | Exclude it and evaluate eligible alternatives | Requisition latency requirement is a hard constraint |
| Secondary supplier has materially lower cost / lead time and good reliability | It may rank first | Weighted total score optimizes the overall trade-off |
| No supplier meets lead-time threshold | Return no-route response | Do not silently violate service-level constraints |
| Combined eligible stock is below requested quantity | Return partial route and unfilled quantity | Expose shortage transparently |
| Split fulfillment is disabled | Use only the highest-ranked offer | Preserve single-route requirement |

## 5. Routing workflow

1. Receive requisition reference, SKU, requested quantity, maximum lead time, and split permission.
2. Query active offers for the SKU, joining supplier and warehouse records.
3. Exclude inactive suppliers, inactive warehouses, inactive offers, zero-stock offers, and offers beyond the lead-time threshold.
4. Normalize cost and lead time across eligible offers.
5. Calculate weighted scores and sort ascending.
6. Allocate requested quantity greedily in ranked order. If split fulfillment is disabled, use only the first offer.
7. Persist the routing decision and its allocations.
8. Return selected supplier/warehouse routes, quantities, score, status, unfilled quantity, fallback indicator, and explanation.

## 6. Fallback and shortage handling

- **Stock fallback:** If the best-ranked offer cannot cover the full quantity, the engine continues to the next eligible offer when split fulfillment is enabled.
- **Latency fallback:** Offers above the requested maximum lead time are filtered out before ranking. The next eligible supplier becomes the preferred route.
- **No eligible offers:** API returns HTTP 404 with an explanatory message.
- **Partial fulfillment:** If total eligible stock is insufficient, the API returns `PARTIALLY_ROUTED`, the allocated quantity, and the unfilled quantity.
- **No split:** When `allow_split=false`, only the best-ranked offer is considered; any shortage is reported as unfilled.
- **Idempotency:** A production extension should accept a unique requisition reference/idempotency key and return the existing decision on duplicate requests. The demonstration implementation persists each evaluation as a new decision; callers should avoid duplicate submissions until idempotency is added.

## 7. Data model

- `routing_warehouses`: warehouse code, name, region, active status.
- `routing_suppliers`: supplier code, name, tier, reliability score, active status.
- `supplier_offers`: supplier, warehouse, SKU, available quantity, unit cost, lead time, active status. A unique constraint prevents duplicate supplier/warehouse/SKU offers.
- `routing_decisions`: requisition reference, SKU, requested and allocated quantity, status, timestamp.
- `routing_allocations`: selected supplier, warehouse, offer, allocated quantity, cost, and lead time.

Foreign keys, check constraints, unique constraints, and indexes protect referential integrity and common lookup paths.

## 8. API contract

**Endpoint:** `POST /routing/evaluate`

Example request:

```json
{
  "requisition_ref": "REQ-100",
  "sku": "SKU-1",
  "quantity": 25,
  "max_lead_time_hours": 48,
  "allow_split": true
}
```

The response includes:
- Decision ID and requisition reference
- Requested, allocated, and unfilled quantities
- `FULLY_ROUTED` or `PARTIALLY_ROUTED` status
- Primary selected supplier
- Supplier/warehouse allocation list
- Fallback indicator and explanation

## 9. Operational considerations and future production hardening

1. Use PostgreSQL transactions and row-level locking or atomic reservations when converting routing allocations into actual inventory commitments.
2. Add unique idempotency keys for requisition evaluation to prevent duplicate decisions.
3. Refresh supplier availability immediately before committing purchase orders; offer quantities can become stale.
4. Store currency and cost basis explicitly (currency code, tax, freight, duties) for multi-region procurement.
5. Add supplier SLA history and rolling on-time-delivery metrics rather than relying only on manually maintained reliability.
6. Add audit events for score inputs, candidate exclusions, and final decision rationale.
7. Consider business rules for warehouse distance, capacity, shipping cost, and regional restrictions.
8. Add authorization so only procurement roles can evaluate or commit requisitions.

## 10. Conclusion

The selected strategy is a weighted, explainable ranking model with hard eligibility gates and greedy multi-offer allocation. It prefers primary suppliers when other factors are comparable, but it can route to secondary suppliers when they offer a better feasible outcome. Latency violations are excluded, stock shortages trigger fallback, and partial fulfillment is explicitly represented rather than hidden.
