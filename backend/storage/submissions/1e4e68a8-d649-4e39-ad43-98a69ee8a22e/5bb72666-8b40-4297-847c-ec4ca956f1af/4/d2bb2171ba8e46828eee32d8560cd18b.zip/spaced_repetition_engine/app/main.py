from datetime import datetime, timedelta, timezone
from fastapi import Depends, FastAPI, HTTPException
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session, sessionmaker
from .models import Base, Card
from .schemas import CardCreate, CardOut, ReviewCreate, ReviewOut
from .scheduler import calculate_next_review

DATABASE_URL = "sqlite:///./spaced_repetition.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base.metadata.create_all(bind=engine)
app = FastAPI(title="Spaced Repetition Engine API", description="Flashcard management and SM-2 review scheduling.", version="1.0.0")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/cards", response_model=CardOut, status_code=201)
def create_card(payload: CardCreate, db: Session = Depends(get_db)):
    card = Card(front=payload.front, back=payload.back)
    db.add(card)
    db.commit()
    db.refresh(card)
    return card

@app.get("/cards", response_model=list[CardOut])
def list_cards(db: Session = Depends(get_db)):
    return db.scalars(select(Card).order_by(Card.id)).all()

@app.get("/cards/due", response_model=list[CardOut])
def due_cards(db: Session = Depends(get_db)):
    now = datetime.now(timezone.utc)
    return db.scalars(select(Card).where(Card.due_at <= now).order_by(Card.due_at)).all()

@app.get("/cards/{card_id}", response_model=CardOut)
def get_card(card_id: int, db: Session = Depends(get_db)):
    card = db.get(Card, card_id)
    if card is None:
        raise HTTPException(status_code=404, detail="Card not found")
    return card

@app.post("/cards/{card_id}/review", response_model=ReviewOut)
def review_card(card_id: int, payload: ReviewCreate, db: Session = Depends(get_db)):
    card = db.get(Card, card_id)
    if card is None:
        raise HTTPException(status_code=404, detail="Card not found")
    repetitions, interval, ease = calculate_next_review(payload.quality, card.repetitions, card.interval_days, card.ease_factor)
    now = datetime.now(timezone.utc)
    card.repetitions, card.interval_days, card.ease_factor = repetitions, interval, ease
    card.last_reviewed_at = now
    card.due_at = now + timedelta(days=interval)
    db.commit()
    db.refresh(card)
    return ReviewOut(card=card, message=f"Next review scheduled in {interval} day(s).")
