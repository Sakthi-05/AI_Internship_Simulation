from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}

def test_create_and_review_card():
    created = client.post("/cards", json={"front": "Hola", "back": "Hello"})
    assert created.status_code == 201
    card_id = created.json()["id"]
    reviewed = client.post(f"/cards/{card_id}/review", json={"quality": 5})
    assert reviewed.status_code == 200
    assert reviewed.json()["card"]["interval_days"] == 1

def test_missing_card_returns_404():
    assert client.post("/cards/999999/review", json={"quality": 4}).status_code == 404

def test_invalid_quality_is_rejected():
    assert client.post("/cards/1/review", json={"quality": 8}).status_code == 422
