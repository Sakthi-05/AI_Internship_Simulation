def calculate_next_review(quality: int, repetitions: int = 0, interval_days: int = 0, ease_factor: float = 2.5) -> tuple[int, int, float]:
    """Return updated repetition count, interval in days, and ease factor using SM-2."""
    if not 0 <= quality <= 5:
        raise ValueError("quality must be between 0 and 5")
    if repetitions < 0 or interval_days < 0:
        raise ValueError("repetitions and interval_days cannot be negative")
    new_ease = max(1.3, ease_factor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)))
    if quality < 3:
        return 0, 1, new_ease
    if repetitions == 0:
        new_interval = 1
    elif repetitions == 1:
        new_interval = 6
    else:
        new_interval = max(1, round(interval_days * ease_factor))
    return repetitions + 1, new_interval, new_ease
