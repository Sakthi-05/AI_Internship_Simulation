import pytest
from app.scheduler import calculate_next_review

def test_first_successful_review_is_one_day():
    assert calculate_next_review(5, 0, 0, 2.5)[:2] == (1, 1)

def test_second_successful_review_is_six_days():
    assert calculate_next_review(4, 1, 1, 2.5)[:2] == (2, 6)

def test_failed_review_resets_repetitions():
    repetitions, interval, ease = calculate_next_review(2, 4, 20, 2.5)
    assert (repetitions, interval) == (0, 1)
    assert ease >= 1.3

def test_invalid_quality_raises():
    with pytest.raises(ValueError):
        calculate_next_review(6)

def test_ease_factor_minimum():
    assert calculate_next_review(0, 0, 0, 1.3)[2] >= 1.3
