# Spaced Repetition Engine API

A FastAPI reference implementation of flashcard review scheduling using the SM-2 algorithm.

## Features
- Create, list, and retrieve flashcards.
- Submit review quality from 0 (complete blackout) to 5 (perfect response).
- Calculate repetition count, review interval, and ease factor.
- Retrieve cards due for review.
- SQLite persistence for a simple local setup.
- Unit tests for scheduling and API behavior.

## Setup

Python 3.10 or newer is recommended.

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

## Run

```bash
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000/docs for interactive API documentation.

## Test

```bash
pytest -q
```

## Endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Health check |
| POST | `/cards` | Create a flashcard |
| GET | `/cards` | List all cards |
| GET | `/cards/due` | List cards due now |
| GET | `/cards/{card_id}` | Retrieve one card |
| POST | `/cards/{card_id}/review` | Submit a review |

Create card request:
```json
{"front": "Hola", "back": "Hello"}
```

Review request:
```json
{"quality": 5}
```

Quality ratings follow SM-2: 0–5, where values below 3 reset the repetition sequence. Successful reviews schedule 1 day, then 6 days, then multiply the previous interval by the ease factor.

## Integration note

This is a self-contained reference implementation using SQLite. It is not connected to the internship platform's existing authentication or database. Adapt it to the host application's conventions before production use.
