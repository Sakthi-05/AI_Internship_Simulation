from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class CardCreate(BaseModel):
    front: str = Field(min_length=1, max_length=500)
    back: str = Field(min_length=1, max_length=2000)

class CardOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    front: str
    back: str
    repetitions: int
    interval_days: int
    ease_factor: float
    due_at: datetime
    last_reviewed_at: datetime | None

class ReviewCreate(BaseModel):
    quality: int = Field(ge=0, le=5)

class ReviewOut(BaseModel):
    card: CardOut
    message: str
